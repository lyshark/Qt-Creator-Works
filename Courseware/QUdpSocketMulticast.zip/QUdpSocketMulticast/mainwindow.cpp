#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    udpSocket=new QUdpSocket(this);

    // 设置为多播
    udpSocket->setSocketOption(QAbstractSocket::MulticastTtlOption,1);

    // 套接字发生变化时触发
    connect(udpSocket,SIGNAL(stateChanged(QAbstractSocket::SocketState)),this,SLOT(onSocketStateChange(QAbstractSocket::SocketState)));
    onSocketStateChange(udpSocket->state());

    // 读取数据信号
    connect(udpSocket,SIGNAL(readyRead()),this,SLOT(onSocketReadyRead()));
}

MainWindow::~MainWindow()
{
    udpSocket->abort();
    delete udpSocket;
    delete ui;
}

// 根据套接字变化选择不同的分支
void MainWindow::onSocketStateChange(QAbstractSocket::SocketState socketState)
{
    switch(socketState)
    {
    case QAbstractSocket::UnconnectedState:
        break;
    case QAbstractSocket::HostLookupState:
        break;
    case QAbstractSocket::ConnectingState:
        break;

    case QAbstractSocket::ConnectedState:
        break;

    case QAbstractSocket::BoundState:
        break;

    case QAbstractSocket::ClosingState:
        break;

    case QAbstractSocket::ListeningState:
        break;
    }
}

// 读取数据报
void MainWindow::onSocketReadyRead()
{
    while(udpSocket->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(udpSocket->pendingDatagramSize());
        QHostAddress peerAddr;
        quint16 peerPort;
        udpSocket->readDatagram(datagram.data(),datagram.size(),&peerAddr,&peerPort);

        QString str=datagram.data();

        QString peer="[从 "+peerAddr.toString()+":"+QString::number(peerPort)+" 发送] ";

        ui->plainTextEdit->appendPlainText(peer+str);
    }
}

// 开始组播
void MainWindow::on_pushButton_start_clicked()
{
    // 获取IP
    QString IP= ui->lineEdit_address->text();
    groupAddress=QHostAddress(IP);

    // 获取端口
    quint16 groupPort = ui->lineEdit_port->text().toUInt();

    // 绑定端口
    if (udpSocket->bind(QHostAddress::AnyIPv4, groupPort, QUdpSocket::ShareAddress))
    {
        // 加入组播
        udpSocket->joinMulticastGroup(groupAddress);
        ui->plainTextEdit->appendPlainText("[*] 加入组播 " + IP + ":" + QString::number(groupPort));
    }
}

// 关闭组播
void MainWindow::on_pushButton_stop_clicked()
{
    // 退出组播
    udpSocket->leaveMulticastGroup(groupAddress);
    udpSocket->abort();
    ui->plainTextEdit->appendPlainText("[-] 退出组播");
}

// 发送组播消息
void MainWindow::on_pushButton_send_clicked()
{
    quint16 groupPort = ui->lineEdit_port->text().toUInt();
    QString msg=ui->lineEdit_msg->text();
    QByteArray datagram=msg.toUtf8();

    udpSocket->writeDatagram(datagram,groupAddress,groupPort);
}
