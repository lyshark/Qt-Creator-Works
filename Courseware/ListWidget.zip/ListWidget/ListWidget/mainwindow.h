#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <iostream>
#include <QIcon>
#include <QMenu>
#include <QListWidget>
#include <QListWidgetItem>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_init_clicked();
    void on_pushButton_edit_clicked();
    void on_pushButton_selectall_clicked();
    void on_pushButton_noselect_clicked();
    void on_pushButton_deselect_clicked();
    void on_pushButton_delete_clicked();
    void on_pushButton_add_clicked();
    void on_pushButton_ins_clicked();

    void on_listWidget_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
