#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}
MainWindow::~MainWindow()
{
    delete ui;
}

// 初始化列表
void MainWindow::on_pushButton_init_clicked()
{
    // 每一行是一个QListWidgetItem
    QListWidgetItem *aItem;

    // 设置ICON的图标
    QIcon aIcon;
    aIcon.addFile(":/image/1.ico");

    // 清空列表框
    ui->listWidget->clear();

    // 循环初始化
    for(int x=0;x<10;x++)
    {
        // 填充字符串
        QString str = QString::asprintf("192.168.1.%d",x);

        // 新建一个项
        aItem = new QListWidgetItem();

        aItem->setText(str);                        // 设置文字标签
        aItem->setIcon(aIcon);                      // 设置图标
        aItem->setCheckState(Qt::Checked);          // 设为选中状态
        aItem->setFlags(Qt::ItemIsSelectable |      // 设置为不可编辑状态
                         Qt::ItemIsUserCheckable
                        |Qt::ItemIsEnabled);

        // 增加项到列表中
        ui->listWidget->addItem(aItem);
    }
}

// 设置所有项设置为可编辑状态
void MainWindow::on_pushButton_edit_clicked()
{
    int x,cnt;
    QListWidgetItem *aItem;

    // 获取所有项数量
    cnt = ui->listWidget->count();
    for(x=0;x<cnt;x++)
    {
        // 得到当前选中项句柄
        aItem = ui->listWidget->item(x);

        // 设置状态
        aItem->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEditable
                        |Qt::ItemIsUserCheckable |Qt::ItemIsEnabled);
    }
}

// 全选按钮
void MainWindow::on_pushButton_selectall_clicked()
{
    // 获取总数
    int cnt = ui->listWidget->count();
    for(int x=0;x<cnt;x++)
    {
        // 获取到项的指针
        QListWidgetItem *aItem = ui->listWidget->item(x);

        // 设置为选中
        aItem->setCheckState(Qt::Checked);
    }

}

// 全不选
void MainWindow::on_pushButton_noselect_clicked()
{
    // 获取总数
    int cnt = ui->listWidget->count();
    for(int x=0;x<cnt;x++)
    {
        // 获取到一项指针
        QListWidgetItem *aItem = ui->listWidget->item(x);

        // 设置为非选中
        aItem->setCheckState(Qt::Unchecked);
    }
}

// 反选
void MainWindow::on_pushButton_deselect_clicked()
{
    int x,cnt;
    QListWidgetItem *aItem;

    // 获取总数
    cnt = ui->listWidget->count();
    for(x=0;x<cnt;x++)
    {
        // 获取到一项指针
        aItem = ui->listWidget->item(x);

        // 如果未选中则选中否则不选
        if(aItem->checkState() != Qt::Checked)
            aItem->setCheckState(Qt::Checked);
        else
            aItem->setCheckState(Qt::Unchecked);
    }
}

// 删除选中项
void MainWindow::on_pushButton_delete_clicked()
{
    // 获取当前行
    int row = ui->listWidget->currentRow();

    // 移除指定行的项,但不delete
    QListWidgetItem *aItem = ui->listWidget->takeItem(row);

    // 释放空间
    delete aItem;
}

// 增加一项,尾部追加
void MainWindow::on_pushButton_add_clicked()
{
    QIcon aIcon;
    aIcon.addFile(":/image/2.ico");

    QListWidgetItem *aItem = new QListWidgetItem("新增的项目");   // 增加项目名
    aItem->setIcon(aIcon);                                       // 设置图标
    aItem->setCheckState(Qt::Checked);                           // 设置为选中
    aItem->setFlags(Qt::ItemIsSelectable |Qt::ItemIsUserCheckable |Qt::ItemIsEnabled);
    ui->listWidget->addItem(aItem);                              // 增加到控件
}

// 指定位置插入一项
void MainWindow::on_pushButton_ins_clicked()
{
    QIcon aIcon;
    aIcon.addFile(":/image/3.ico");

    QListWidgetItem *aItem = new QListWidgetItem("插入的数据");
    aItem->setIcon(aIcon);
    aItem->setCheckState(Qt::Checked);
    aItem->setFlags(Qt::ItemIsSelectable |Qt::ItemIsUserCheckable |Qt::ItemIsEnabled);

    // 在当前行的上方插入一个项
    ui->listWidget->insertItem(ui->listWidget->currentRow(),aItem);
}

// listWidget 当前选中项发生变化
void MainWindow::on_listWidget_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous)
{
    QString str;

    // 需要检测变量指针是否为空
    if (current != NULL)
    {
      // 需要检测变量指针是否为空
      if (previous==NULL)
        str="当前："+current->text();
      else
        str="前一项：" + previous->text() + "; 当前项：" + current->text();

      std::cout << str.toStdString().data() << std::endl;
    }
}
