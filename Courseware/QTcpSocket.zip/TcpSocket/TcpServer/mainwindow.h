#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtNetwork>
#include <QTcpServer>
#include <QTcpSocket>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

// 自定义槽函数
private slots:

    // newConnection()信号
    void onNewConnection();

    // 状态改变信号
    void onSocketStateChange(QAbstractSocket::SocketState socketState);

    // 客户连接信号
    void onClientConnected();

    // 客户关闭信号
    void onClientDisconnected();

    // 读取socket传入的数据
    void onSocketReadyRead();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QTcpServer *tcpServer; // TCP服务器
    QTcpSocket *tcpSocket; // TCP通讯的Socket
};
#endif // MAINWINDOW_H
