#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 新建TCP套接字类
    tcpServer=new QTcpServer(this);

    // 连接信号初始化其他信号
    connect(tcpServer,SIGNAL(newConnection()),this,SLOT(onNewConnection()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 初始化信号槽函数
void MainWindow::onNewConnection()
{
    // 创建新套接字
    tcpSocket = tcpServer->nextPendingConnection();

    // 连接触发信号
    connect(tcpSocket, SIGNAL(connected()),this, SLOT(onClientConnected()));
    onClientConnected();

    // 关闭触发信号
    connect(tcpSocket, SIGNAL(disconnected()),this, SLOT(onClientDisconnected()));

    // 状态改变触发信号
    connect(tcpSocket,SIGNAL(stateChanged(QAbstractSocket::SocketState)),this,SLOT(onSocketStateChange(QAbstractSocket::SocketState)));
    onSocketStateChange(tcpSocket->state());

    // 读入数据触发信号
    connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(onSocketReadyRead()));
}

// Socket状态变化时
void MainWindow::onSocketStateChange(QAbstractSocket::SocketState socketState)
{
    switch(socketState)
    {
    case QAbstractSocket::UnconnectedState:
        ui->plainTextEdit->appendPlainText("Scoket状态：UnconnectedState");
        break;
    case QAbstractSocket::HostLookupState:
        ui->plainTextEdit->appendPlainText("Scoket状态：HostLookupState");
        break;
    case QAbstractSocket::ConnectingState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ConnectingState");
        break;

    case QAbstractSocket::ConnectedState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ConnectedState");
        break;

    case QAbstractSocket::BoundState:
        ui->plainTextEdit->appendPlainText("Scoket状态：BoundState");
        break;

    case QAbstractSocket::ClosingState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ClosingState");
        break;

    case QAbstractSocket::ListeningState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ListeningState");
    }
}

// 客户端接入时
void MainWindow::onClientConnected()
{
    ui->plainTextEdit->appendPlainText("[*] 客户端进入");
    ui->plainTextEdit->appendPlainText(" IP地址:"+ tcpSocket->peerAddress().toString());
    ui->plainTextEdit->appendPlainText(" Port端口:"+QString::number(tcpSocket->peerPort()));
}

// 客户端断开连接时
void MainWindow::onClientDisconnected()
{
    ui->plainTextEdit->appendPlainText("[-] 客户端断开");
    tcpSocket->deleteLater();
}

// 读取缓冲区行文本
void MainWindow::onSocketReadyRead()
{
    while(tcpSocket->canReadLine())
        ui->plainTextEdit->appendPlainText("[接收] | " + tcpSocket->readLine());
}

// 开始侦听
void MainWindow::on_pushButton_2_clicked()
{
    // 此处指定绑定本机的8888端口
    tcpServer->listen(QHostAddress::LocalHost,8888);
    ui->plainTextEdit->appendPlainText("[+] 开始监听");
    ui->plainTextEdit->appendPlainText(" 服务器地址：" + tcpServer->serverAddress().toString() +
                                       " 服务器端口："+QString::number(tcpServer->serverPort())
                                       );
}

// 停止侦听
void MainWindow::on_pushButton_3_clicked()
{
    if (tcpServer->isListening())
    {
        tcpServer->close();
    }
}

// 发送数据
void MainWindow::on_pushButton_clicked()
{
    QString  msg=ui->lineEdit->text();
    ui->plainTextEdit->appendPlainText("[发送] | " + msg);

    QByteArray str=msg.toUtf8();
    str.append('\n');
    tcpSocket->write(str);
}
