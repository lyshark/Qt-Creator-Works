#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    tcpClient=new QTcpSocket(this);

    connect(tcpClient,SIGNAL(connected()),this,SLOT(onConnected()));
    connect(tcpClient,SIGNAL(disconnected()),this,SLOT(onDisconnected()));
    connect(tcpClient,SIGNAL(stateChanged(QAbstractSocket::SocketState)),this,SLOT(onSocketStateChange(QAbstractSocket::SocketState)));
    connect(tcpClient,SIGNAL(readyRead()),this,SLOT(onSocketReadyRead()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 连接时触发
void MainWindow::onConnected()
{
    ui->plainTextEdit->appendPlainText("[*] 已连接到服务器");
}

// 断开连接时触发
void MainWindow::onDisconnected()
{
    ui->plainTextEdit->appendPlainText("[-] 已断开与服务器的连接");
}

// 读取数据时触发
void MainWindow::onSocketReadyRead()
{
    while(tcpClient->canReadLine())
    {
        ui->plainTextEdit->appendPlainText("[接收] | " + tcpClient->readLine());
    }
}

// 信号改变时触发
void MainWindow::onSocketStateChange(QAbstractSocket::SocketState socketState)
{
    switch(socketState)
    {
    case QAbstractSocket::UnconnectedState:
        ui->plainTextEdit->appendPlainText("Scoket状态：UnconnectedState");
        break;
    case QAbstractSocket::HostLookupState:
        ui->plainTextEdit->appendPlainText("Scoket状态：HostLookupState");
        break;
    case QAbstractSocket::ConnectingState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ConnectingState");
        break;

    case QAbstractSocket::ConnectedState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ConnectedState");
        break;

    case QAbstractSocket::BoundState:
        ui->plainTextEdit->appendPlainText("Scoket状态：BoundState");
        break;

    case QAbstractSocket::ClosingState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ClosingState");
        break;

    case QAbstractSocket::ListeningState:
        ui->plainTextEdit->appendPlainText("Scoket状态：ListeningState");
    }
}

// 连接服务器时触发
void MainWindow::on_pushButton_2_clicked()
{
    // 连接到8888端口
    tcpClient->connectToHost(QHostAddress::LocalHost,8888);
}

// 断开时触发
void MainWindow::on_pushButton_3_clicked()
{
    if (tcpClient->state()==QAbstractSocket::ConnectedState)
        tcpClient->disconnectFromHost();
}

// 发送消息时触发
void MainWindow::on_pushButton_clicked()
{
    QString  msg=ui->lineEdit->text();
    ui->plainTextEdit->appendPlainText("[发送] | " + msg);
    QByteArray str=msg.toUtf8();
    str.append('\n');
    tcpClient->write(str);
}
