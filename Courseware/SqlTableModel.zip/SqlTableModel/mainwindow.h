#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>


#pragma execution_character_set("utf-8")


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void InitSQL();
    void getFieldNames();

private:
    Ui::MainWindow *ui;

private slots:
    void on_currentRowChanged(const QModelIndex &current, const QModelIndex &previous);
    void on_pushButton_add_clicked();
    void on_pushButton_insert_clicked();
    void on_pushButton_delete_clicked();
    void on_pushButton_save_clicked();
    void on_pushButton_reset_clicked();
    void on_pushButton_ascending_clicked();
    void on_pushButton_descending_clicked();
    void on_pushButton_filter_man_clicked();
    void on_pushButton_default_clicked();
    void on_pushButton_clicked();
};

#endif // MAINWINDOW_H
