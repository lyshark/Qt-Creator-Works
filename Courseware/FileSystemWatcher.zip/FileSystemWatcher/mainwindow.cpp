#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "filesystem.h"
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 选择一个目录
void MainWindow::on_pushButton_clicked()
{
    // 创建一个目录选择对话框
    QString directory = QFileDialog::getExistingDirectory(this, "选择目录", QDir::homePath());

    // 处理选择的目录
    if (!directory.isEmpty())
    {
        ui->lineEdit->setText(directory);
    }
}

// 开始监控
void MainWindow::on_pushButton_2_clicked()
{
    FileSystemWatcher::addWatchPath(ui->lineEdit->text());
}
