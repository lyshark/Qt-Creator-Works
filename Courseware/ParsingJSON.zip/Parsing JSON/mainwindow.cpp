#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>

#include <QString>
#include <QTextStream>
#include <QMessageBox>

#include <QFile>
#include <QDir>
#include <QFileInfo>

#include <QJsonDocument>
#include <QJsonParseError>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonValueRef>

#include <QListView>
#include <QStandardItemModel>

// 定义全局字符串
QString config;

// 读取JSON文本
QString readonly_string(QString file_path)
{
    QFile this_file_ptr(file_path);
    if(false == this_file_ptr.exists())
    {
        return "None";
    }
    if(false == this_file_ptr.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        return "None";
    }
    QString string_value = this_file_ptr.readAll();
    this_file_ptr.close();
    return string_value;
}


// 写出JSON到文件
bool writeonly_string(QString file_path, QString file_data)
{
    QFile this_file_ptr(file_path);
    if(false == this_file_ptr.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        return false;
    }

    QByteArray write_byte = file_data.toUtf8();

    this_file_ptr.write(write_byte,write_byte.length());
    this_file_ptr.close();
    return true;
}

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 读取文件
    config = readonly_string("config.json");
    if(config == "None")
    {
        QMessageBox::information(nullptr,"提示","读取失败",QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(nullptr,"提示","JSON文件已被读入",QMessageBox::Ok);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 1.1 解析键值对
void MainWindow::on_pushButton_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 解析blog字段
    QString blog = root_object.find("blog").value().toString();
    //std::cout << "字段对应的值 = > "<< blog.toStdString() << std::endl;
    ui->lineEdit_blog->setText(blog);

    // 解析enable字段
    bool enable = root_object.find("enable").value().toBool();
    //std::cout << "是否开启状态: " << enable << std::endl;
    ui->lineEdit_enable->setText(QString::number(enable));

    // 解析status字段
    int status = root_object.find("status").value().toInt();
    //std::cout << "状态数值: " << status << std::endl;
    ui->lineEdit_status->setText(QString::number(status));
}

// 1.2 解析单数组键值
void MainWindow::on_pushButton_2_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 解析单一对象
    QJsonObject get_dict_ptr = root_object.find("GetDict").value().toObject();
    QVariantMap map = get_dict_ptr.toVariantMap();

    if(map.contains("address") && map.contains("username") && map.contains("password") && map.contains("update"))
    {
        QString address = map["address"].toString();
        QString username = map["username"].toString();
        QString password = map["password"].toString();
        QString update = map["update"].toString();

        std::cout
               << " 地址: " << address.toStdString()
               << " 用户名: " << username.toStdString()
               << " 密码: " << password.toStdString()
               << " 更新日期: " << update.toStdString()
               << std::endl;

        ui->listWidget->addItem(address);
        ui->listWidget->addItem(username);
        ui->listWidget->addItem(password);
        ui->listWidget->addItem(update);
    }

    // 解析单一数组
    QJsonArray get_list_ptr = root_object.find("GetList").value().toArray();

    for(int index=0; index < get_list_ptr.count(); index++)
    {
        int ref_value = get_list_ptr.at(index).toInt();
        std::cout << "输出数组元素: " << ref_value << std::endl;

        ui->listWidget_2->addItem(QString::number(ref_value));
    }
}

// 1.3 解析多数组键值
void MainWindow::on_pushButton_3_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 找到Object对象
    QJsonObject one_object_json = root_object.find("ObjectInArrayJson").value().toObject();

    // 转为MAP映射
    QVariantMap map = one_object_json.toVariantMap();

    // 寻找One键
    QJsonArray array_one = map["One"].toJsonArray();

    for(int index=0; index < array_one.count(); index++)
    {
        QString value = array_one.at(index).toString();

        std::cout << "One => "<< value.toStdString() << std::endl;
        ui->comboBox->addItem(value);
    }

    // 寻找Two键
    QJsonArray array_two = map["Two"].toJsonArray();

    for(int index=0; index < array_two.count(); index++)
    {
        QString value = array_two.at(index).toString();

        std::cout << "Two => "<< value.toStdString() << std::endl;
        ui->comboBox_2->addItem(value);
    }
}

// 1.3 解析多数组键值
void MainWindow::on_pushButton_4_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 获取MyJson数组
    QJsonValue array_value = root_object.value("ArrayJson");

    // 验证节点是否为数组
    if(array_value.isArray())
    {
        // 得到数组个数
        int array_count = array_value.toArray().count();

        // 循环数组个数
        for(int index=0;index <= array_count;index++)
        {
            QJsonValue parset = array_value.toArray().at((index));
            if(parset.isArray())
            {
                QString address = parset.toArray().at(0).toString();
                QString username = parset.toArray().at(1).toString();
                QString userport = parset.toArray().at(2).toString();

                std::cout
                        << "地址: " << address.toStdString()
                        << " 用户名: " << username.toStdString()
                        << " 端口号: " << userport.toStdString()
                << std::endl;

                ui->comboBox_3->addItem(address);
                ui->comboBox_4->addItem(username);
                ui->comboBox_5->addItem(userport);
            }
        }
    }
}

// 1.4 解析多字典键值
void MainWindow::on_pushButton_5_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 获取MyJson数组
    QJsonValue object_value = root_object.value("ObjectJson");

    // 验证是否为数组
    if(object_value.isArray())
    {
        // 获取对象个数
        int object_count = object_value.toArray().count();

        // 循环个数
        for(int index=0;index <= object_count;index++)
        {
            QJsonObject obj = object_value.toArray().at(index).toObject();

            // 验证数组不为空
            if(!obj.isEmpty())
            {
                QString address = obj.value("address").toString();
                QString username = obj.value("username").toString();

                std::cout << "地址: " << address.toStdString() << " 用户: " << username.toStdString() << std::endl;
                ui->comboBox_6->addItem(address);
                ui->comboBox_7->addItem(username);
            }
        }
    }
}

// 1.4 解析多字典键值
void MainWindow::on_pushButton_6_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 获取MyJson数组
    QJsonValue object_value = root_object.value("ObjectArrayJson");

    // 验证是否为数组
    if(object_value.isArray())
    {
        // 获取对象个数
        int object_count = object_value.toArray().count();

        // 循环个数
        for(int index=0;index <= object_count;index++)
        {
            QJsonObject obj = object_value.toArray().at(index).toObject();

            // 验证数组不为空
            if(!obj.isEmpty())
            {
                QString uname = obj.value("uname").toString();
                std::cout << "用户名: " << uname.toStdString() <<  std::endl;

                ui->comboBox_8->addItem(uname);

                // 解析该用户的数组
                int array_count = obj.value("ulist").toArray().count();

                std::cout << "数组个数: "<< array_count << std::endl;

                for(int index=0;index < array_count;index++)
                {
                    QJsonValue parset = obj.value("ulist").toArray().at(index);

                    int val = parset.toInt();

                    std::cout << "Value = > "<< val << std::endl;
                    ui->comboBox_9->addItem(QString::number(val));
                }
            }
        }
    }
}

// 触发信号
void MainWindow::on_comboBox_8_currentIndexChanged(const QString &arg1)
{
    ui->comboBox_9->clear();

    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        return;
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 获取MyJson数组
    QJsonValue object_value = root_object.value("ObjectArrayJson");

    // 验证是否为数组
    if(object_value.isArray())
    {
        // 获取对象个数
        int object_count = object_value.toArray().count();

        // 循环个数
        for(int index=0;index <= object_count;index++)
        {
            QJsonObject obj = object_value.toArray().at(index).toObject();

            // 验证数组不为空
            if(!obj.isEmpty())
            {
                QString uname = obj.value("uname").toString();
                std::cout << "用户名: " << uname.toStdString() <<  std::endl;

                // 解析该用户的数组
                int array_count = obj.value("ulist").toArray().count();

                std::cout << "数组个数: "<< array_count << std::endl;

                for(int index=0;index < array_count;index++)
                {

                    // 相等则解析
                    if(uname.compare(arg1) == 0)
                    {
                        QJsonValue parset = obj.value("ulist").toArray().at(index);

                        int val = parset.toInt();

                        std::cout << "Value = > "<< val << std::endl;
                        ui->comboBox_9->addItem(QString::number(val));
                    }
                }
            }
        }
    }
}

// 1.5 解析多字典嵌套
void MainWindow::on_pushButton_7_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 获取NestingObjectJson数组
    QJsonValue array_value = root_object.value("NestingObjectJson");

    // 验证节点是否为数组
    if(array_value.isArray())
    {
        // 得到内部对象个数
        int count = array_value.toArray().count();
        std::cout << "对象个数: " << count << std::endl;

        for(int index=0; index < count; index++)
        {
            // 得到数组中的index下标中的对象
            QJsonObject array_object = array_value.toArray().at(index).toObject();

            QString uuid = array_object.value("uuid").toString();

            // 追加数据
            std::cout << uuid.toStdString() << std::endl;
            ui->comboBox_10->addItem(uuid);

            // 开始解析basic中的数据
            QJsonObject basic = array_object.value("basic").toObject();

            QString lat = basic.value("lat").toString();
            QString lon = basic.value("lon").toString();

            std::cout << "解析basic中的lat字段: " << lat.toStdString() << std::endl;
            std::cout << "解析basic中的lon字段: " << lon.toStdString()<< std::endl;

            // 解析单独字段
            QString status = array_object.value("status").toString();
            std::cout << "解析字段状态: " << status.toStdString() << std::endl;
        }
    }
}

// 触发currentIndexChanged
void MainWindow::on_comboBox_10_currentIndexChanged(const QString &arg1)
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        QMessageBox::information(nullptr,"提示","JSON格式错误",QMessageBox::Ok);
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 获取NestingObjectJson数组
    QJsonValue array_value = root_object.value("NestingObjectJson");

    // 验证节点是否为数组
    if(array_value.isArray())
    {
        // 得到内部对象个数
        int count = array_value.toArray().count();
        std::cout << "对象个数: " << count << std::endl;

        for(int index=0; index < count; index++)
        {
            // 得到数组中的index下标中的对象
            QJsonObject array_object = array_value.toArray().at(index).toObject();

            QString uuid = array_object.value("uuid").toString();

            // 对比是否相等
            if(uuid.compare(arg1) == 0)
            {
                // 开始解析basic中的数据
                QJsonObject basic = array_object.value("basic").toObject();

                QString lat = basic.value("lat").toString();
                QString lon = basic.value("lon").toString();

                std::cout << "解析basic中的lat字段: " << lat.toStdString() << std::endl;
                std::cout << "解析basic中的lon字段: " << lon.toStdString()<< std::endl;

                ui->lineEdit->setText(lat);
                ui->lineEdit_2->setText(lon);

                // 解析单独字段
                QString status = array_object.value("status").toString();
                std::cout << "解析字段状态: " << status.toStdString() << std::endl;
            }
        }
    }
}

// 1.5 解析多字典嵌套
void MainWindow::on_pushButton_8_clicked()
{
    // 字符串格式化为JSON
    QJsonParseError err_rpt;
    QJsonDocument  root_document = QJsonDocument::fromJson(config.toUtf8(), &err_rpt);
    if(err_rpt.error != QJsonParseError::NoError)
    {
        std::cout << "json 格式错误" << std::endl;
    }

    // 获取到Json字符串的根节点
    QJsonObject root_object = root_document.object();

    // 获取NestingObjectJson数组
    QJsonValue array_value = root_object.value("ArrayNestingArrayJson");

    // 验证节点是否为数组
    if(array_value.isArray())
    {
        // 得到数组中的0号下标中的对象
        QJsonObject array_object = array_value.toArray().at(0).toObject();

        // 解析手机号字符串
        QString telephone = array_object.value("telephone").toString();
        std::cout << "手机号: " << telephone.toStdString() << std::endl;

        ui->comboBox_11->addItem(telephone);

        // 定位外层数组
        QJsonArray root_array = array_object.find("path").value().toArray();
        std::cout << "外层循环计数: " << root_array.count() << std::endl;

        for(int index=0; index < root_array.count(); index++)
        {
            // 定位内层数组
            QJsonArray sub_array = root_array.at(index).toArray();
            std::cout << "内层循环计数: "<< sub_array.count() << std::endl;

            for(int sub_count=0; sub_count < sub_array.count(); sub_count++)
            {
                // 每次取出最里层数组元素
                float var = sub_array.toVariantList().at(sub_count).toFloat();

                std::cout << "输出元素: " << var << std::endl;
                // std::cout << sub_array.toVariantList().at(0).toFloat() << std::endl;

                ui->listWidget_3->addItem(QString::number(var));
            }
        }
    }
}
