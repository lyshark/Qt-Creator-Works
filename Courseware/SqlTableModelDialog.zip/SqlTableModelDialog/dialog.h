#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QSqlRecord>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

    QSqlRecord getRecordData();
    void setUpdateRecord(QSqlRecord &recData);
    void setInsertRecord(QSqlRecord &recData);

private:
    Ui::Dialog *ui;
    QSqlRecord  mRecord; //����һ����¼������
};

#endif // DIALOG_H
