#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 查询本机IP地址
void MainWindow::on_pushButton_clicked()
{
    // 本地主机名
    QString hostName=QHostInfo::localHostName();
    std::cout << hostName.toStdString() << std::endl;
    ui->lineEdit->setText(hostName);

    // 查询主机IP地址信息
    QHostInfo hostInfo=QHostInfo::fromName(hostName);

    QList<QHostAddress> addList=hostInfo.addresses();
    if (!addList.isEmpty())
    for (int i=0;i<addList.count();i++)
    {
        // 每一项是一个QHostAddress
        QHostAddress aHost=addList.at(i);

        // 判断是否为IPV4
        if(QAbstractSocket::IPv4Protocol==aHost.protocol())
        {
            ui->listWidget->addItem("IPV4 | " + aHost.toString());
        }
        else
        {
            ui->listWidget->addItem("IPV6 | " + aHost.toString());
        }
    }
}

//查找主机信息的槽函数
void MainWindow::lookedUpHostInfo(const QHostInfo &host)
{
    // 每一项是一个QHostAddress
    QList<QHostAddress> addList=host.addresses();
    if (!addList.isEmpty())
    for (int i=0;i<addList.count();i++)
    {
        QHostAddress aHost=addList.at(i);

        // 判断是否为IPV4
        if(QAbstractSocket::IPv4Protocol==aHost.protocol())
        {
            ui->listWidget_2->addItem("IPV4 | " + aHost.toString());
        }
        else
        {
            ui->listWidget_2->addItem("IPV6 | " + aHost.toString());
        }
    }
}

// 查询其他域名IP地址
void MainWindow::on_pushButton_2_clicked()
{
    // 主机名
    QString hostname=ui->lineEdit_2->text();
    QHostInfo::lookupHost(hostname,this,SLOT(lookedUpHostInfo(QHostInfo)));
}
