#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 设置Combobox选择框
void MainWindow::CallProcess()
{
    ui->comboBox->clear();

    QProcess process;
    process.start("tasklist", QStringList() << "/FO" << "CSV");

    if (process.waitForFinished())
    {
        QString output = process.readAllStandardOutput();

        // 去掉所有引号字符
        output.replace("\"", "");

        QStringList lines = output.split("\n");

        // 跳过第一行标题
        for(int i = 1; i < lines.size(); ++i)
        {
            QStringList fields = lines[i].split(",");

            // 确保至少有一个字段（进程名称）
            if(fields.size() >= 1)
            {
                QString processName = fields[0].trimmed();

                // 将进程名称添加到 ComboBox 中
                ui->comboBox->addItem(processName);
            }
        }
    } else
    {
        ui->comboBox->addItem("Error.");
    }
}







// 获取进程列表
void MainWindow::on_pushButton_clicked()
{
    CallProcess();

    ui->treeWidget->clear();

    QProcess process;
    process.start("tasklist", QStringList() << "/FO" << "CSV");

    if (process.waitForFinished())
    {
        QString output = process.readAllStandardOutput();
        output.replace("\"", "");

        QStringList lines = output.split("\n");

        // 跳过第一行标题
        for(int i = 1; i < lines.size(); ++i)
        {
            QStringList fields = lines[i].split(",");

            // 确保至少有五个字段
            if(fields.size() >= 5)
            {
                QStringList rowData;
                for(int j = 0; j < 5; ++j)
                {
                    rowData << fields[j].trimmed();
                }
                ui->treeWidget->addTopLevelItem(new QTreeWidgetItem(rowData));
            }
        }

        // 设置列标题
        ui->treeWidget->setHeaderLabels(QStringList() << "进程名称" << "PID" << "会话名称" << "Session"<< "内存占用");
    } else
    {
        QTreeWidgetItem *item = new QTreeWidgetItem(ui->treeWidget);
        item->setText(0, "Failed to execute tasklist command.");
    }
}

// 获取系统进程信息
void MainWindow::on_pushButton_2_clicked()
{
    ui->treeWidget->clear();

    // 获取系统信息
    QProcess process;
    process.start("systeminfo");

    if (process.waitForFinished())
    {
     QByteArray output = process.readAllStandardOutput();

     // 使用正确的文本编码对输出进行解码
     QTextCodec *codec = QTextCodec::codecForName("GBK");
     QString text = codec->toUnicode(output);

     QStringList lines = text.split("\n");
     for (const QString &line : lines)
     {
         // 解析系统信息，添加到 QTreeWidget 中
         QStringList fields = line.split(":", Qt::SkipEmptyParts);
         if (fields.size() >= 2)
         {
             QString property = fields[0].trimmed();
             QString value = fields[1].trimmed();

             QTreeWidgetItem *item = new QTreeWidgetItem(ui->treeWidget);
             item->setText(0, property);
             item->setText(1, value);
         }
     }

     // 设置列标题
     ui->treeWidget->setHeaderLabels(QStringList() << "系统信息" << "数值");
    } else
    {
     QTreeWidgetItem *item = new QTreeWidgetItem(ui->treeWidget);
     item->setText(0, "Failed to execute systeminfo command.");
    }
}

// 终止进程
void MainWindow::on_pushButton_3_clicked()
{
    // 获取 ComboBox 中当前选中的进程名称
    QString processName = ui->comboBox->currentText();

    // 终止选中的进程
    QProcess killProcess;
    killProcess.start("taskkill", QStringList() << "/IM" << processName);
    killProcess.waitForFinished();
}
