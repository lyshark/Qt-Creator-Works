﻿#ifndef QWCHARTVIEW_H
#define QWCHARTVIEW_H
#include <QMouseEvent>
#include <QWheelEvent>
#include <QKeyEvent>
#include <iostream>
#include <QtCharts>
#include <QChartView>

QT_CHARTS_USE_NAMESPACE

class QWChartView : public QChartView
{
    Q_OBJECT

private:
    QPoint  beginPoint;  // 选择矩形区的起点
    QPoint  endPoint;    // 选择矩形区的终点

protected:
    // 鼠标左键按下
    void mousePressEvent(QMouseEvent *event);
    // 鼠标移动
    void mouseMoveEvent(QMouseEvent *event);
    // 鼠标释放左键
    void mouseReleaseEvent(QMouseEvent *event);
    // 鼠标滚轮事件
    void wheelEvent(QWheelEvent *event);
    // 按键事件
    void keyPressEvent(QKeyEvent *event);

public:
    explicit QWChartView(QWidget *parent = 0);
    ~QWChartView();

signals:
    // 鼠标移动信号在mouseMoveEvent()事件中触发
    void mouseMovePoint(QPoint point);
};

#endif // QWCHARTVIEW_H
