﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qwchartview.h"

MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->graphicsView);

    // 创建图表的各个部件
    QChart *chart = new QChart();

    // 设置顶部标题
    chart->setTitle("系统性能统计图");

    // 将Chart添加到ChartView
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 设置图表主题色
    ui->graphicsView->chart()->setTheme(QChart::ChartTheme(7));

    // 设置动画效果
    ui->graphicsView->chart()->setAnimationOptions(QChart::AnimationOptions(3));

    // ------------------------------------------
    // 设置图例字体与颜色
    // ------------------------------------------

    // 获取当前字体
    QFont font = ui->graphicsView->chart()->legend()->font();

    // 设置字体
    font.setFamily("Arial");
    font.setPointSize(10);
    font.setBold(true);

    // 设置到页面
    ui->graphicsView->chart()->legend()->setFont(font);

    // ------------------------------------------
    // 创建曲线序列
    // ------------------------------------------

    QLineSeries *series0 = new QLineSeries();
    QLineSeries *series1 = new QLineSeries();
    QLineSeries *series2 = new QLineSeries();

    // 为序列设置名字
    series0->setName("一分钟负载");
    series1->setName("五分钟负载");
    series2->setName("十五分钟负载");

    // 为曲线指定类型和属性
    QPen pen;

    // 设置线条类型：Qt::SolidLine, Qt::DashLine, Qt::DotLine, Qt::DashDotLine
    pen.setStyle(Qt::DotLine);
    pen.setWidth(2);             // 设置序列宽度
    pen.setColor(Qt::green);     // 设置绿色
    series0->setPen(pen);        // 折线序列的线条设置

    // 设置线条类型：Qt::SolidLine, Qt::DashLine, Qt::DotLine, Qt::DashDotLine
    pen.setStyle(Qt::SolidLine);
    pen.setColor(Qt::blue);      // 设置蓝色
    pen.setWidth(2);             // 设置序列宽度
    series1->setPen(pen);        // 折线序列的线条设置

    // 设置线条类型：Qt::SolidLine, Qt::DashLine, Qt::DotLine, Qt::DashDotLine
    pen.setStyle(Qt::DashDotLine);
    pen.setColor(Qt::red);       // 设置蓝色
    pen.setWidth(2);             // 设置序列宽度
    series2->setPen(pen);        // 折线序列的线条设置

    // 为序列曲线设置颜色
    QColor color;
    color.setRgb(170,0,255,255);   // 紫色配色
    series0->setColor(color);      // 设置序列0

    // 将序列添加到图表
    chart->addSeries(series0);
    chart->addSeries(series1);
    chart->addSeries(series2);

    // -----------------------------------------------
    // 坐标轴配置
    // -----------------------------------------------

    // 创建坐标轴X
    QValueAxis *axisX = new QValueAxis;

    axisX->setRange(0, 10);             // 设置坐标轴范围
    axisX->setLabelFormat("%.1f");      // 标签格式
    axisX->setTickCount(11);            // 主分隔个数
    axisX->setMinorTickCount(4);        // 设置轴上每个刻度之间的小刻度数量
    axisX->setTitleText("X轴坐标");      // 标题

    // 创建坐标轴Y
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(-2, 2);
    axisY->setTitleText("Y轴坐标");
    axisY->setTickCount(5);
    axisY->setLabelFormat("%.2f");
    axisY->setMinorTickCount(4);

    // 设置坐标轴
    chart->addAxis(axisX,Qt::AlignBottom);
    chart->addAxis(axisY,Qt::AlignLeft);

     //序列 series0 附加坐标轴
    series0->attachAxis(axisX);
    series0->attachAxis(axisY);

    //序列 series1 附加坐标轴
    series1->attachAxis(axisX);
    series1->attachAxis(axisY);

    //序列 series2 附加坐标轴
    series2->attachAxis(axisX);
    series2->attachAxis(axisY);

    // ---------------------------------------------------
    // 开始初始化数据
    // ---------------------------------------------------

    // 获取指针
    series0=(QLineSeries *)ui->graphicsView->chart()->series().at(0);
    series1=(QLineSeries *)ui->graphicsView->chart()->series().at(1);
    series2=(QLineSeries *)ui->graphicsView->chart()->series().at(2);

    // 清空图例
    series0->clear();
    series1->clear();
    series2->clear();

    // 随机数初始化
    qsrand(QTime::currentTime().second());

    qreal t=0,y1,y2,y3,intv=0.1;
    qreal rd;
    int cnt=100;
    for(int i=0;i<cnt;i++)
    {
        rd=(qrand() % 10)-5;       // 随机数,-5~+5
        y1=qSin(t)+rd/50;
        *series0<<QPointF(t,y1);   // 序列添加数据点

        rd=(qrand() % 10)-5;       // 随机数,-5~+5
        y2=qCos(t)+rd/50;
        *series1<<QPointF(t,y2);   // 序列添加数据点

        rd=(qrand() % 40)+20;      // 随机数,-40~+20
        y3=qCos(t)+rd/50;
        *series2<<QPointF(t,y3);   // 序列添加数据点
        t+=intv;
    }

    // -----------------------------------------------
    // 绑定信号与槽
    // -----------------------------------------------

    // 图例被点击后触发
    foreach (QLegendMarker* marker, chart->legend()->markers())
    {
       QObject::disconnect(marker, SIGNAL(clicked()), this, SLOT(on_LegendMarkerClicked()));
       QObject::connect(marker, SIGNAL(clicked()), this, SLOT(on_LegendMarkerClicked()));
    }

    // 鼠标移动后触发
    QObject::connect(ui->graphicsView,SIGNAL(mouseMovePoint(QPoint)),this, SLOT(on_mouseMovePoint(QPoint)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 槽函数：处理图例标记点击事件，显示或隐藏与之关联的数据系列
void MainWindow::on_LegendMarkerClicked()
{
    // 将发送者强制转换为 QLegendMarker 类型
    QLegendMarker* marker = qobject_cast<QLegendMarker*>(sender());

    // 检查标记的类型
    switch (marker->type())
    {
        case QLegendMarker::LegendMarkerTypeXY:
        {
            // 切换数据系列的可见性
            marker->series()->setVisible(!marker->series()->isVisible());

            // 设置标记可见
            marker->setVisible(true);

            // 根据数据系列的可见性设置标记的透明度
            qreal alpha = 1.0;
            if (!marker->series()->isVisible())
                alpha = 0.5;

            // 调整标记的标签刷颜色透明度
            QColor color;
            QBrush brush = marker->labelBrush();
            color = brush.color();
            color.setAlphaF(alpha);
            brush.setColor(color);
            marker->setLabelBrush(brush);

            // 调整标记的刷颜色透明度
            brush = marker->brush();
            color = brush.color();
            color.setAlphaF(alpha);
            brush.setColor(color);
            marker->setBrush(brush);

            // 调整标记的画笔颜色透明度
            QPen pen = marker->pen();
            color = pen.color();
            color.setAlphaF(alpha);
            pen.setColor(color);
            marker->setPen(pen);

            break;
        }
        default:
            break;
    }
}

// 鼠标移动响应获取鼠标位置
void MainWindow::on_mouseMovePoint(QPoint point)
{
    QPointF pt=ui->graphicsView->chart()->mapToValue(point);
    std::cout << QString::asprintf("X=%.1f,Y=%.2f",pt.x(),pt.y()).toStdString() << std::endl;
}
