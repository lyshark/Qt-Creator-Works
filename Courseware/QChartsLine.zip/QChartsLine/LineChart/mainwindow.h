#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QtCharts>
#include <iostream>
#include "qwchartview.h"

QT_CHARTS_USE_NAMESPACE

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private slots:
    // 图例单击槽函数
    void on_LegendMarkerClicked();
     // 鼠标移动事件
    void on_mouseMovePoint(QPoint point);
private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
