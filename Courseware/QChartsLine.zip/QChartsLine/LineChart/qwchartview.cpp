﻿#include "qwchartview.h"
#include <QChartView>

// 鼠标左键按下
void QWChartView::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        // 记录左键按下时的起始点
        beginPoint = event->pos();
    }

    // 调用基类的鼠标按下事件处理函数
    QChartView::mousePressEvent(event);
}

// 鼠标移动事件
void QWChartView::mouseMoveEvent(QMouseEvent *event)
{
    // 获取当前鼠标的位置
    QPoint point = event->pos();

    // 发射鼠标移动信号
    emit mouseMovePoint(point);

    // 调用基类的鼠标移动事件处理函数
    QChartView::mouseMoveEvent(event);
}

// 鼠标左键释放
void QWChartView::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        // 获取矩形框的 endPoint
        endPoint = event->pos();

        // 创建矩形框
        QRectF rectF;
        rectF.setTopLeft(this->beginPoint);
        rectF.setBottomRight(this->endPoint);

        // 在矩形框内进行缩放
        this->chart()->zoomIn(rectF);
    }
    else if (event->button() == Qt::RightButton)
    {
        // 右键点击时，重置缩放
        this->chart()->zoomReset();
    }

    // 调用基类的鼠标释放事件处理函数
    QChartView::mouseReleaseEvent(event);
}

// 鼠标滚轮事件
qint16 g_x = 0;
void QWChartView::wheelEvent(QWheelEvent *event)
{
    // 当滚轮向上滑
    if (event->delta() > 0)
    {
        g_x = g_x + 1;
        this->chart()->zoom(g_x);
    }
    // 当滚轮向下滑
    else
    {
        g_x = g_x - 1;
        this->chart()->zoom(g_x);
    }
}

// 按键控制
void QWChartView::keyPressEvent(QKeyEvent *event)
{
    switch (event->key())
    {
    case Qt::Key_Plus:
        // 按 "+" 键放大
        chart()->zoom(1.2);
        break;
    case Qt::Key_Minus:
        // 按 "-" 键缩小
        chart()->zoom(0.8);
        break;
    case Qt::Key_Left:
        // 按左箭头键左移
        chart()->scroll(10, 0);
        break;
    case Qt::Key_Right:
        // 按右箭头键右移
        chart()->scroll(-10, 0);
        break;
    case Qt::Key_Up:
        // 按上箭头键上移
        chart()->scroll(0, -10);
        break;
    case Qt::Key_Down:
        // 按下箭头键下移
        chart()->scroll(0, 10);
        break;
    case Qt::Key_PageUp:
        // 按 PageUp 键上移
        chart()->scroll(0, 50);
        break;
    case Qt::Key_PageDown:
        // 按 PageDown 键下移
        chart()->scroll(0, -50);
        break;
    case Qt::Key_Home:
        // 按 Home 键重置缩放
        chart()->zoomReset();
        break;
    default:
        // 其他键交给基类处理
        QGraphicsView::keyPressEvent(event);
    }
}

QWChartView::QWChartView(QWidget *parent) : QChartView(parent)
{
    // 设置拖拽模式和鼠标追踪
    this->setDragMode(QGraphicsView::RubberBandDrag);
    this->setMouseTracking(true);
}

QWChartView::~QWChartView()
{
    // 析构函数
}
