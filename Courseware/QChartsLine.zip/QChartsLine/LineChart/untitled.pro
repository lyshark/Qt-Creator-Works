#-------------------------------------------------
#
# Project created by QtCreator
#
#-------------------------------------------------

QT       += core gui

QT       += charts

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = untitled
TEMPLATE = app


SOURCES += main.cpp\
        mainwindow.cpp \
    qwchartview.cpp

HEADERS  += mainwindow.h \
    qwchartview.h

FORMS    += mainwindow.ui

RESOURCES +=
