#include "mainwindow.h"
#include "ui_mainwindow.h"

// 鼠标按下事件
void MainWindow::mousePressEvent(QMouseEvent * event)
{
    if(event->button() == Qt::LeftButton)
    {
        ui->lineEdit_l->setText("左键按下");
    }
    else if(event->button() == Qt::RightButton)
    {
       ui->lineEdit_r->setText("右键按下");
    }
}

// 鼠标释放事件
void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
       ui->lineEdit_l->setText("左键释放");
    }
    else if(event->button() == Qt::RightButton)
    {
       ui->lineEdit_r->setText("右键释放");
    }
}

// 鼠标移动事件
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        ui->lineEdit_l->setText("左键移动");
    }
    else if(event->button() == Qt::RightButton)
    {
        ui->lineEdit_r->setText("右键移动");
    }

    // 获取移动过程中的鼠标指针坐标
    ui->lineEdit_x->setText(QString::number(event->x()));
    ui->lineEdit_y->setText(QString::number(event->y()));
}

qint32 g_x=0;
qint32 g_y=0;

// 鼠标滚轮事件
void MainWindow::wheelEvent(QWheelEvent *event)
{
    // 当滚轮向上滑
    if(event->delta() > 0)
    {
        g_x = g_x+1;
        ui->lineEdit_box->setText(QString::number(g_x));
    }
    // 当滚轮向下滑
    else
    {
        g_y = g_y-1;
        ui->lineEdit_box->setText(QString::number(g_y));
    }
}

// 键盘按下事件
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    // 是否按下Ctrl键
    if(event->modifiers() == Qt::ControlModifier)
    {
        // 是否按下M键
        if(event->key() == Qt::Key_M)
        {
            std::cout << "Ctrl + M" << std::endl;
        }
    }
    else
    {
        //保存默认事件
       QWidget::keyPressEvent(event);
    }

    // 如果是处理两个普通按键
    if(event->key() == Qt::Key_Up)
     {
        // 按键重复时不做处理
        if(event->isAutoRepeat())
        {
            return;
        }
    }
}

// 键盘抬起事件
void MainWindow::keyReleaseEvent(QKeyEvent *event)
{
    // 如果是处理两个普通按键得避免自动重复
    if(event->key() == Qt::Key_Up)
    {
        if(event->isAutoRepeat())
        {
            return;
        }
    }
}

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

