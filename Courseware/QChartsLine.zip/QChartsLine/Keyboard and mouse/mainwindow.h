#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QKeyEvent>
#include <iostream>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    // 鼠标按下事件
    void mousePressEvent(QMouseEvent * event);
    // 鼠标释放事件
    void mouseReleaseEvent(QMouseEvent *event);
    // 鼠标移动事件
    void mouseMoveEvent(QMouseEvent *event);
    // 鼠标滚轮事件
    void wheelEvent(QWheelEvent *event);
    // 键盘按下事件
    void keyPressEvent(QKeyEvent *event);
    // 键盘抬起事件
    void keyReleaseEvent(QKeyEvent *event);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
