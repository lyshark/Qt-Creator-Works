#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QItemSelectionModel>
#include <QtCharts>
#include <QTime>
#include <QBarSet>
#include <QChart>

QT_CHARTS_USE_NAMESPACE

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void InitTable();
    void DrawBarChart();
    void DrawPieChart();
    void DrawStackingDiagram();
    void DrawPercentageChart();
    void DrawScatterPlot();

private slots:
    void on_PieSliceHighlight(bool show);
    void on_chartBarLegendMarkerClicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
