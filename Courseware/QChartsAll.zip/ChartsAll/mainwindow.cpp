#include "mainwindow.h"
#include "ui_mainwindow.h"

QStandardItemModel *theModel;

// 初始化数据
void MainWindow::InitTable()
{
    // --------------------------------------------------------------
    // 初始化表格中的数据
    // --------------------------------------------------------------

    // 初始化学生个数为40 | 数据模型为5列
    theModel = new QStandardItemModel(40,5,this);

    // 设置表头
    QStringList headerList;
    headerList<<"用户ID"<<"数学"<<"语文"<<"英语"<<"平均分";
    theModel->setHorizontalHeaderLabels(headerList);

    // 设置随机数种子
    qsrand(QTime::currentTime().second());
    for (int i=0;i<theModel->rowCount();i++)
    {
        // 生成随机用户ID
        QString studName=QString::asprintf("%2d",i+1);
        QStandardItem* aItem=new QStandardItem(studName);
        aItem->setTextAlignment(Qt::AlignHCenter);

        // 将ID设置到第一列
        theModel->setItem(i,0,aItem);

        qreal avgScore=0;

        // 这里的1-3代表三门课程成绩
        // 通过循环三次以此初始化一行用户的语数英成绩
        for (int j=1;j<=3;j++)
        {
            qreal score=50.0+(qrand() % 50);
            avgScore+=score;

            aItem=new QStandardItem(QString::asprintf("%.0f",score));
            aItem->setTextAlignment(Qt::AlignHCenter);

            // 将成绩插入到j行
            theModel->setItem(i,j,aItem);
        }

        // 最后一个平均值通过新建一个QStandardItem来实现创建
        aItem=new QStandardItem(QString::asprintf("%.1f",avgScore/3));
        aItem->setTextAlignment(Qt::AlignHCenter);

        // 设置为不可编辑
        aItem->setFlags(aItem->flags() & (!Qt::ItemIsEditable));

        // 将平均分插入到第4列
        theModel->setItem(i,4,aItem);
    }

    // --------------------------------------------------------------
    // 随机生成填充数据
    // --------------------------------------------------------------

    // 记录小于60、60到69、70到79、80到89、大于等于90的数量
    int countBelow60, count60to69, count70to79, count80to89, countAbove90;

    // 记录总和、最小值、最大值
    qreal totalSum, minValue, maxValue;

    // 用于存储每个单元格的值
    qreal cellValue;

    // 节点
    QTreeWidgetItem *item;

    int row, column;
    for (column = 1; column <= 4; column++)
    {
        // 初始化各项统计值
        totalSum = 0;
        countBelow60 = 0;
        count60to69 = 0;
        count70to79 = 0;
        count80to89 = 0;
        countAbove90 = 0;

        // 遍历每一行数据
        for (row = 0; row < theModel->rowCount(); row++)
        {
            // 获取当前单元格的值
            cellValue = theModel->item(row, column)->text().toDouble();

            // 统计最小值和最大值
            if (row == 0)
            {
                minValue = cellValue;
                maxValue = cellValue;
            }
            if (cellValue < minValue)
                minValue = cellValue;
            if (cellValue > maxValue)
                maxValue = cellValue;

            // 统计总和
            totalSum += cellValue;

            // 根据值的范围进行分组统计
            if (cellValue < 60)
                countBelow60++;
            else if ((cellValue >= 60) && (cellValue < 70))
                count60to69++;
            else if ((cellValue >= 70) && (cellValue < 80))
                count70to79++;
            else if ((cellValue >= 80) && (cellValue < 90))
                count80to89++;
            else
                countAbove90++;
        }

        // 更新TreeWidget中的统计结果
        item = ui->treeWidget->topLevelItem(0);  // <60
        item->setText(column, QString::number(countBelow60));
        item->setTextAlignment(column, Qt::AlignHCenter);

        item = ui->treeWidget->topLevelItem(1);  // 60
        item->setText(column, QString::number(count60to69));
        item->setTextAlignment(column, Qt::AlignHCenter);

        item = ui->treeWidget->topLevelItem(2);  // 70
        item->setText(column, QString::number(count70to79));
        item->setTextAlignment(column, Qt::AlignHCenter);

        item = ui->treeWidget->topLevelItem(3);  // 80
        item->setText(column, QString::number(count80to89));
        item->setTextAlignment(column, Qt::AlignHCenter);

        item = ui->treeWidget->topLevelItem(4);  // 90
        item->setText(column, QString::number(countAbove90));
        item->setTextAlignment(column, Qt::AlignHCenter);

        item = ui->treeWidget->topLevelItem(5);  // average
        item->setText(column, QString::number(totalSum / theModel->rowCount()));
        item->setTextAlignment(column, Qt::AlignHCenter);

        item = ui->treeWidget->topLevelItem(6);  // max
        item->setText(column, QString::number(maxValue));
        item->setTextAlignment(column, Qt::AlignHCenter);

        item = ui->treeWidget->topLevelItem(7);  // min
        item->setText(column, QString::number(minValue));
        item->setTextAlignment(column, Qt::AlignHCenter);
    }

    // 设置数据模型
    ui->tableView->setModel(theModel);
}

// 绘制柱状图
void MainWindow::DrawBarChart()
{
    // ------------------------------------------------
    // 图表初始化
    // ------------------------------------------------
    QChart *chart = new QChart();
    chart->setTitle("柱状图统计");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    // 为graphicsView设置chart
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 构造柱状图
    chart =ui->graphicsView->chart();
    chart->removeAllSeries(); //删除所有序列

    chart->removeAxis(chart->axisX()); //删除坐标轴
    chart->removeAxis(chart->axisY()); //删除坐标轴

    // 创建三个QBarSet数据集 从数据模型的表头获取Name
    QBarSet *setMath = new QBarSet(theModel->horizontalHeaderItem(1)->text());      // 数学字段
    QBarSet *setChinese = new QBarSet(theModel->horizontalHeaderItem(2)->text());   // 语文字段
    QBarSet *setEnglish= new QBarSet(theModel->horizontalHeaderItem(3)->text());    // 英语字段

    // 创建折线线条
    QLineSeries *Line = new QLineSeries();
    Line->setName(theModel->horizontalHeaderItem(4)->text());  // 表示平均分
    QPen pen;
    pen.setColor(Qt::red);  // 使用红色
    pen.setWidth(2);        // 设置宽度
    Line->setPen(pen);      // 绘制

    for(int i=0;i< 10;i++)
    {
        //从数据模型获取数据
        setMath->append(theModel->item(i,1)->text().toInt()); //数学
        setChinese->append(theModel->item(i,2)->text().toInt()); //语文
        setEnglish->append(theModel->item(i,3)->text().toInt()); //英语
        Line->append(QPointF(i,theModel->item(i,4)->text().toFloat()));  //平均分
    }

    // 创建柱状图序列 QBarSeries, 并添加三个数据集
    QBarSeries *series = new QBarSeries();
    series->append(setMath);
    series->append(setChinese);
    series->append(setEnglish);

    chart->addSeries(series); // 添加柱状图序列
    chart->addSeries(Line);   // 添加折线图序列

    // 用于横坐标在字符串列表 即UID
    QStringList categories;
    for (int i=0;i<10;i++)
    {
        categories <<theModel->item(i,0)->text();
    }

    // 柱状图的坐标轴
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);            // 添加横坐标文字列表
    chart->setAxisX(axisX, series);       // 设置横坐标
    chart->setAxisX(axisX, Line);         // 设置横坐标

    // 设置坐标范围
    axisX->setRange(categories.at(0), categories.at(categories.count()-1));

    // 数值型坐标作为纵轴
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(0, 100);
    axisY->setTitleText("分数");
    axisY->setTickCount(6);
    axisY->setLabelFormat("%.0f");

    chart->setAxisY(axisY, series);
    chart->setAxisY(axisY, Line);
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);
}

// 绘制饼状图
void MainWindow::DrawPieChart()
{
    // 饼图初始化
    QChart *chart = new QChart();
    chart->setAnimationOptions(QChart::SeriesAnimations);
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 绘制饼图
    chart->removeAllSeries();

    // 创建饼图序列
    QPieSeries *series = new QPieSeries();

    // 饼图中间空心的大小
    series->setHoleSize(0.30);

    // 添加分块数据
    for (int i=0;i<=4;i++)
    {
        // 获得QTreeWidgetItem的item
        QTreeWidgetItem* item=ui->treeWidget->topLevelItem(i);

        // 获取分析对象，数学、英语、语文或平均分,添加一个饼图分块数据,标签，数值
        series->append(item->text(0),item->text(1).toFloat());
    }

    // 饼图分块
    QPieSlice *slice;

    // 设置每个分块的标签文字
    for(int i=0;i<=4;i++)
    {
        // 获取分块
        slice =series->slices().at(i);

        // 设置分块的标签
        slice->setLabel(slice->label()+QString::asprintf(": %.0f人, %.1f%%", slice->value(),slice->percentage()*100));

        // 信号与槽函数关联，鼠标落在某个分块上时，此分块弹出
        connect(slice, SIGNAL(hovered(bool)),this, SLOT(on_PieSliceHighlight(bool)));
    }

    slice->setExploded(true);           // 最后一个设置为exploded
    series->setLabelsVisible(true);     // 只影响当前的slices，必须添加完slice之后再设置
    chart->addSeries(series);           // 添加饼图序列

    chart->legend()->setVisible(true);  // 图例
    chart->legend()->setAlignment(Qt::AlignRight);
}

// 绘制堆叠图
void MainWindow::DrawStackingDiagram()
{
    // 初始化叠加柱状图绘制窗口
    QChart *chart = new QChart();
    chart->setAnimationOptions(QChart::SeriesAnimations);
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 绘制叠加柱状图
    chart->removeAllSeries();
    chart->removeAxis(chart->axisX());
    chart->removeAxis(chart->axisY());

    // 创建三门课程的数据集
    QBarSet *setMath = new QBarSet(theModel->horizontalHeaderItem(1)->text());
    QBarSet *setChinese = new QBarSet(theModel->horizontalHeaderItem(2)->text());
    QBarSet *setEnglish= new QBarSet(theModel->horizontalHeaderItem(3)->text());

    // 添加前十个分数数据到数据集
    for(int i=0;i<20;i++)
    {
        setMath->append(theModel->item(i,1)->text().toInt());
        setChinese->append(theModel->item(i,2)->text().toInt());
        setEnglish->append(theModel->item(i,3)->text().toInt());
    }

    // 创建QStackedBarSeries对象并添加数据集
    QStackedBarSeries *series = new QStackedBarSeries();
    series->append(setMath);
    series->append(setChinese);
    series->append(setEnglish);
    series->setLabelsVisible(true);

    // 添加序列到图表
    chart->addSeries(series);

    QStringList categories;

    // 绘制前十个数据
    for (int i=0;i<10;i++)
    {
        categories <<theModel->item(i,0)->text();
    }

    // 类别坐标轴 作为横轴
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->setAxisX(axisX, series);
    axisX->setRange(categories.at(0), categories.at(categories.count()-1));

    // 数值坐标轴 作为纵轴
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(0, 300);
    axisY->setTitleText("总分");
    axisY->setTickCount(6);
    axisY->setLabelFormat("%.0f");
    chart->setAxisY(axisY, series);

    // 设置图表属性
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);
}

// 绘制百分比图
void MainWindow::DrawPercentageChart()
{
    // 百分比柱状图初始化
    QChart *chart = new QChart();
    chart->setAnimationOptions(QChart::SeriesAnimations);
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 绘制百分比柱状图
    chart->removeAllSeries();
    chart->removeAxis(chart->axisX());
    chart->removeAxis(chart->axisY());

    // 创建数据集
    QBarSet *setMath = new QBarSet(theModel->horizontalHeaderItem(1)->text());
    QBarSet *setChinese = new QBarSet(theModel->horizontalHeaderItem(2)->text());
    QBarSet *setEnglish= new QBarSet(theModel->horizontalHeaderItem(3)->text());

    QTreeWidgetItem *item;
    QStringList categories;

    for (int i=0;i<=4;i++)
    {
        // 从分数段统计数据表里获取数据添加到数据集
        item=ui->treeWidget->topLevelItem(i);

        // 横坐标的标签
        categories<<item->text(0);

        // 添加数据到QBarSet中
        setMath->append(item->text(1).toFloat());
        setChinese->append(item->text(2).toFloat());
        setEnglish->append(item->text(3).toFloat());
    }

    // 添加序列
    QPercentBarSeries *series = new QPercentBarSeries();
    series->append(setMath);
    series->append(setChinese);
    series->append(setEnglish);
    series->setLabelsVisible(true);
    series->setLabelsFormat("@value人");
    chart->addSeries(series);

    // 添加横坐标
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->setAxisX(axisX, series);
    axisX->setRange(categories.at(0), categories.at(categories.count()-1));

    // 添加纵坐标
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(0, 100);
    axisY->setTitleText("百分比");
    axisY->setTickCount(6);
    axisY->setLabelFormat("%.1f");
    chart->setAxisY(axisY, series);

    // 设置属性
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignRight);
}

// 绘制散点图
void MainWindow::DrawScatterPlot()
{
    // 散点图初始化
    QChart *chart = new QChart();
    chart->setAnimationOptions(QChart::SeriesAnimations);
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 清空绘图区
    chart->removeAllSeries();
    chart->removeAxis(chart->axisX());
    chart->removeAxis(chart->axisY());

    // 光滑曲线序列
    QSplineSeries *seriesLine = new QSplineSeries();
    seriesLine->setName("曲线");
    QPen pen;
    pen.setColor(Qt::blue);
    pen.setWidth(2);
    seriesLine->setColor(Qt::blue);
    seriesLine->setPen(pen);

    // 散点序列
    QScatterSeries *series0 = new QScatterSeries();
    series0->setName("散点");
    series0->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    series0->setBorderColor(Qt::black);
    series0->setBrush(QBrush(Qt::red));
    series0->setMarkerSize(12);

    // 随机数种子
    qsrand(QTime::currentTime().second());

    // 设置曲线随机数
    for (int i=0;i<10;i++)
    {
        int x=(qrand() % 20);    // 0到20之间的随机数
        int y=(qrand() % 20);
        series0->append(x,y);    // 散点序列
        seriesLine->append(x,y); // 光滑曲线序列
    }

    chart->addSeries(series0);
    chart->addSeries(seriesLine);

    // 增加Y坐标轴（可注释）
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(0, 20);
    axisY->setTitleText("Y坐标");
    axisY->setTickCount(11);
    axisY->setLabelFormat("%.0f");
    axisY->setGridLineVisible(true);
    chart->setAxisY(axisY, series0);
    chart->setAxisY(axisY, seriesLine);

    // 增加X坐标轴（可注释）
    QValueAxis *axisX = new QValueAxis;
    axisX->setRange(0, 20);
    axisX->setTitleText("X");
    axisX->setTickCount(11);
    axisX->setLabelFormat("%.0f");
    axisX->setGridLineVisible(true);
    chart->setAxisX(axisX, series0);
    chart->setAxisX(axisX, seriesLine);

    // 创建缺省的坐标轴（默认缺省值）
    chart->createDefaultAxes();
    chart->axisX()->setTitleText("X 轴");
    chart->axisX()->setRange(-2,22);

    chart->axisY()->setTitleText("Y 轴");
    chart->axisY()->setRange(-2,22);

    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignRight);

    // 绑定槽函数，用于点击图例显示与隐藏数据
    foreach (QLegendMarker* marker, chart->legend()->markers())
    {
        QObject::disconnect(marker, SIGNAL(clicked()), this, SLOT(on_chartBarLegendMarkerClicked()));
        QObject::connect(marker, SIGNAL(clicked()), this, SLOT(on_chartBarLegendMarkerClicked()));
    }
}

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 初始化数据
    InitTable();

    DrawPieChart();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 鼠标移入移出时触发hovered信号
void MainWindow::on_PieSliceHighlight(bool show)
{
    QPieSlice *slice;
    slice=(QPieSlice *)sender();

    // 动态设置setExploded效果
    // slice->setLabelVisible(show);
    slice->setExploded(show);
}

// 散点图显示与隐藏
void MainWindow::on_chartBarLegendMarkerClicked()
{
    QLegendMarker* marker = qobject_cast<QLegendMarker*> (sender());

    switch (marker->type())
    {
        case QLegendMarker::LegendMarkerTypeXY:
        {
            marker->series()->setVisible(!marker->series()->isVisible());
            marker->setVisible(true);
            break;
        }

        case QLegendMarker::LegendMarkerTypeBar:
        {
            marker->series()->setVisible(!marker->series()->isVisible());
            marker->setVisible(true);
            break;
        }

        default:
            break;
    }
}
