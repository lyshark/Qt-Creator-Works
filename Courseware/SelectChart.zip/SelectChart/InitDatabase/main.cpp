#include <QCoreApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>
#include <iostream>
#include <QStringList>
#include <QString>
#include <QVariant>
#include <QDebug>
#include <QDateTime>
#include <QTime>

// 延时函数
void Sleep(int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}

// 生成随机数
int GetRandom()
{
    int num = qrand() % 100;
    return num;
}

// 生成随机IP地址
QString GetRandomIP()
{
    int part1 = 192;  // 固定第一个部分为192
    int part2 = 168;  // 固定第二个部分为168
    int part3 = 1;    // 固定第三个部分为1
    int part4 = qrand() % 10 + 1;  // 生成1到10之间的随机整数

    QString ipAddress = QString("%1.%2.%3.%4").arg(part1).arg(part2).arg(part3).arg(part4);

    return ipAddress;
}


// 初始化数据表
void InitSql()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");

    db.setDatabaseName("database.sqlite3");
    if (!db.open())
    {
           std::cout << db.lastError().text().toStdString()<< std::endl;
           return;
    }

   // 执行SQL创建表
   db.exec("DROP TABLE Times");
   db.exec("CREATE TABLE Times ("
                   "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                   "address VARCHAR(64) NOT NULL, "
                   "datetime VARCHAR(128) NOT NULL, "
                   "value INTEGER NOT NULL"
           ")"
        );

   db.commit();
   db.close();
}

// 插入数据
void InsertSQL()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("database.sqlite3");
     if (!db.open())
     {
            std::cout << db.lastError().text().toStdString()<< std::endl;
            return;
     }

     for(int index=0;index <99999;index++)
     {
        QString address = GetRandomIP();
        QDateTime curDateTime = QDateTime::currentDateTime();
        QString date_time = curDateTime.toString("yyyy-MM-dd hh:mm:ss");
        int value = GetRandom();

        QString run_sql = QString("INSERT INTO Times(id,address,datetime,value) VALUES (%1,'%2','%3',%4);")
                                  .arg(index).arg(address).arg(date_time).arg(value);
        std::cout << "insert: " << run_sql.toStdString() << std::endl;

        db.exec(run_sql);
        db.commit();
        Sleep(1000);
     }
     db.close();
}

// 查询记录测试
void SelectSQL()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("database.sqlite3");
     if (!db.open())
     {
            std::cout << db.lastError().text().toStdString()<< std::endl;
            return;
     }

    // 查询数据
    QSqlQuery query("SELECT * FROM Times;",db);
    QSqlRecord rec = query.record();

    // 循环所有记录
    while(query.next())
    {
        // 判断当前记录是否有效
        if(query.isValid())
        {
            int id_value = query.value(rec.indexOf("id")).toInt();
            QString address_value = query.value(rec.indexOf("address")).toString();
            QString date_time = query.value(rec.indexOf("datetime")).toString();
            int this_value = query.value(rec.indexOf("value")).toInt();

            if(date_time.toStdString() >= "2024-01-06 14:18:23" && date_time.toStdString() <="2024-01-06 14:30:03")
            {
                std::cout << "value: " << this_value << std::endl;
            }
        }
    }
}


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // 生成随机数种子
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    //InitSql();
    //InsertSQL();
    SelectSQL();
    return a.exec();
}
