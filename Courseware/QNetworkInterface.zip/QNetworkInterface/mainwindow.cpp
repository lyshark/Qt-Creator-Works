#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 获取网卡数量
    QList<QNetworkInterface> list=QNetworkInterface::allInterfaces();

    // 转换为字符串
    QString countString = QString::number(list.count());
    ui->lineEdit->setText(countString);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QList<QNetworkInterface> list=QNetworkInterface::allInterfaces();
    for(int i=0;i<list.count();i++)
    {
        QNetworkInterface aInterface=list.at(i);
        if (!aInterface.isValid())
           continue;

        ui->plainTextEdit->appendPlainText("设备名称："+aInterface.humanReadableName());
        ui->plainTextEdit->appendPlainText("硬件地址："+aInterface.hardwareAddress());
        QList<QNetworkAddressEntry> entryList=aInterface.addressEntries();
        for(int j=0;j<entryList.count();j++)
        {
            QNetworkAddressEntry aEntry=entryList.at(j);
            ui->plainTextEdit->appendPlainText("IP 地址："+aEntry.ip().toString());
            ui->plainTextEdit->appendPlainText("子网掩码："+aEntry.netmask().toString());
            ui->plainTextEdit->appendPlainText("广播地址："+aEntry.broadcast().toString());
        }

        ui->plainTextEdit->appendPlainText(" ------------------------------------------- ");
        ui->plainTextEdit->appendPlainText("\n");
    }
}
