#include "mainwindow.h"
#include "ui_mainwindow.h"

void InitMultipleSQL()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("./database.db");
     if (!db.open())
     {
            std::cout << db.lastError().text().toStdString()<< std::endl;
            return;
     }

    // 执行SQL创建User表并插入测试数据
    db.exec("DROP TABLE User");
    db.exec("CREATE TABLE User ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "name VARCHAR(40) NOT NULL)"
         );

    db.exec("INSERT INTO User(name) VALUES('lyshark')");
    db.exec("INSERT INTO User(name) VALUES('root')");
    db.exec("INSERT INTO User(name) VALUES('admin')");

    // 创建第二张表,与第一张表通过姓名关联起来
    db.exec("DROP TABLE UserAddressList");
    db.exec("CREATE TABLE UserAddressList("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "name VARCHAR(40) NOT NULL, "
            "address VARCHAR(128) NOT NULL"
            ")");

    db.exec("INSERT INTO UserAddressList(name,address) VALUES ('lyshark','192.168.1.1')");
    db.exec("INSERT INTO UserAddressList(name,address) VALUES ('lyshark','192.168.1.2')");
    db.exec("INSERT INTO UserAddressList(name,address) VALUES ('lyshark','192.168.1.3')");
    db.exec("INSERT INTO UserAddressList(name,address) VALUES ('root','192.168.10.10')");
    db.exec("INSERT INTO UserAddressList(name,address) VALUES ('root','192.168.10.11')");
    db.exec("INSERT INTO UserAddressList(name,address) VALUES ('admin','192.168.100.100')");

    db.commit();
    db.close();
}

QSqlDatabase db;

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    InitMultipleSQL();

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("./database.db");
     if (!db.open())
     {
            std::cout << db.lastError().text().toStdString()<< std::endl;
            return;
     }

     QSqlQuery query;
     query.exec("select * from User;");
     QSqlRecord rec = query.record();

     while(query.next())
     {
         int index_name = rec.indexOf("name");
         QString data_name = query.value(index_name).toString();
         ui->comboBox_user->addItem(data_name);
     }
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 槽函数触发
void MainWindow::on_comboBox_user_activated(const QString &arg1)
{
    if(db.open())
    {
        QSqlQuery query;
        query.prepare("select * from UserAddressList where name = :x");
        query.bindValue(":x",arg1);
        query.exec();

        QSqlRecord rec = query.record();

        ui->comboBox_address->clear();
        while(query.next())
        {
            int index = rec.indexOf("address");
            QString data_ = query.value(index).toString();
            ui->comboBox_address->addItem(data_);
        }
    }
}
