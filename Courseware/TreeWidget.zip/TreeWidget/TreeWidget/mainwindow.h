#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <iostream>
#include <QTreeWidgetItem>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // 分别为添加根节点与添加子节点
    QTreeWidgetItem * AddTreeRoot(QString name,QString desc);
    QTreeWidgetItem * AddTreeNode(QTreeWidgetItem *parent,QString name,QString desc);

private slots:
    void on_treeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column);
    void on_treeWidget_itemClicked(QTreeWidgetItem *item, int column);

    void on_pushButton_add_clicked();
    void on_pushButton_addsubnode_clicked();
    void on_pushButton_modifynode_clicked();
    void on_pushButton_delnode_clicked();
    void on_pushButton_enumnode_clicked();
    void on_pushButton_getnode_clicked();
    void on_pushButton_enumselectnode_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
