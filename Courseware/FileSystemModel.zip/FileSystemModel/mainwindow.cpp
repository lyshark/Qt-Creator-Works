﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 新建类指针
    model=new QFileSystemModel(this);

    // 设置根目录
    model->setRootPath(QDir::currentPath());

    // 设置过滤器
    QStringList filter;
    filter << "*.exe" << "*.txt" << "*.mp4";

    // 使用过滤器
    model->setNameFilters(filter);
    model->setNameFilterDisables(false);

    // 设置数据模型
    ui->treeView->setModel(model);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 被点击后触发
void MainWindow::on_treeView_clicked(const QModelIndex &index)
{
    // 是否是目录
    ui->chkIsDir->setChecked(model->isDir(index));
    // 文件路径
    ui->LabPath->setText(model->filePath(index));

    // 文件类型
    ui->LabType->setText(model->type(index));

    // 文件名
    ui->LabFileName->setText(model->fileName(index));

    // 文件的大小
    int sz=model->size(index)/1024;
    if (sz<1024)
    {

        ui->LabFileSize->setText(QString("%1 KB").arg(sz));
    }
    else
    {
        ui->LabFileSize->setText(QString::asprintf("%.1f MB",sz/1024.0));
    }
}
