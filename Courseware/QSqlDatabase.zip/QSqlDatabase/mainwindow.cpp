#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 初始化数据库
void MainWindow::on_pushButton_clicked()
{
    // 指定数据库驱动类型
    QSqlDatabase db = QSqlDatabase::addDatabase(ui->lineEdit_type->text());
    db.setDatabaseName(ui->lineEdit_dir->text());
     if (!db.open())
     {
            QMessageBox::information(nullptr, "信息", db.lastError().text(), QMessageBox::Ok);
     }

     // 获取文本内容
     QString plainText = ui->plainTextEdit->toPlainText();

     // 使用 split() 函数分割成行
     QStringList lines = plainText.split('\n', Qt::SkipEmptyParts);

     // 遍历每一行
     for (const QString &line : lines)
     {
         db.exec(line);
     }

    // 提交事务请求
    bool ref = db.commit();
    if(ref == true)
    {
        QMessageBox::information(nullptr, "信息", "初始化失败", QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(nullptr, "信息", "执行初始化成功", QMessageBox::Ok);
    }

    db.close();
}

// 插入数据
void MainWindow::on_pushButton_2_clicked()
{
    // 指定数据库驱动类型
    QSqlDatabase db = QSqlDatabase::addDatabase(ui->lineEdit_type->text());
    db.setDatabaseName(ui->lineEdit_dir->text());
     if (!db.open())
     {
            QMessageBox::information(nullptr, "信息", db.lastError().text(), QMessageBox::Ok);
     }

     // 获取文本内容
     QString plainText = ui->plainTextEdit->toPlainText();

     // 使用 split() 函数分割成行
     QStringList lines = plainText.split('\n', Qt::SkipEmptyParts);

     // 遍历每一行
     for (const QString &line : lines)
     {
         db.exec(line);
     }

    // 提交事务请求
    bool ref = db.commit();
    if(ref == true)
    {
        QMessageBox::information(nullptr, "信息", "插入数据失败", QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(nullptr, "信息", "插入数据成功", QMessageBox::Ok);
    }

    db.close();
}


// 批量插入数据
void MainWindow::on_pushButton_3_clicked()
{
    // 指定数据库驱动类型
    QSqlDatabase db = QSqlDatabase::addDatabase(ui->lineEdit_type->text());
    db.setDatabaseName(ui->lineEdit_dir->text());
    if (!db.open())
    {
        QMessageBox::information(nullptr, "信息", db.lastError().text(), QMessageBox::Ok);
    }

    // 定义字符串链表
    QStringList user_name;
    QStringList user_age;

    // 获取文本内容
    QString plainText_uname = ui->plainTextEdit_uname->toPlainText();
    QString plainTextEdit_uage = ui->plainTextEdit_uage->toPlainText();

    // 使用 split() 函数分割成行
    QStringList lines_uname = plainText_uname.split('\n', Qt::SkipEmptyParts);
    QStringList lines_uage = plainTextEdit_uage.split('\n', Qt::SkipEmptyParts);

    // 遍历每一行
    for (const QString &line : lines_uname)
    {
        user_name.append(line);
    }

    for (const QString &line : lines_uage)
    {
        user_age.append(line);
    }

    // 绑定数据记录
    QSqlQuery query;
    query.prepare("INSERT INTO LyShark(name,age) ""VALUES (:name, :age)");

    // 判断两张表中字段数据量是否一致
    if(user_name.size() == user_age.size())
    {
        // 循环插入数据
        for(int x=0;x< user_name.size(); x++)
        {
            query.bindValue(":name",user_name[x]);
            query.bindValue(":age",user_age[x]);
            query.exec();
        }
    }

    // 提交事务请求
    bool ref = db.commit();
    if(ref == true)
    {
        QMessageBox::information(nullptr, "信息", "插入数据失败", QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(nullptr, "信息", "插入数据成功", QMessageBox::Ok);
    }

    db.close();
}

// 查询表中数据
void MainWindow::on_pushButton_4_clicked()
{
    // 指定数据库驱动类型
    QSqlDatabase db = QSqlDatabase::addDatabase(ui->lineEdit_type->text());
    db.setDatabaseName(ui->lineEdit_dir->text());
    if (!db.open())
    {
        QMessageBox::information(nullptr, "信息", db.lastError().text(), QMessageBox::Ok);
    }

    // 查询数据
    QSqlQuery query("SELECT * FROM LyShark;",db);
    QSqlRecord rec = query.record();

    // 循环所有记录
    while(query.next())
    {
        // 判断当前记录是否有效
        if(query.isValid())
        {
            // 读出数据
            int id_ptr = rec.indexOf("id");
            int id_value = query.value(id_ptr).toInt();

            int name_ptr = rec.indexOf("name");
            QString name_value = query.value(name_ptr).toString();

            int age_ptr = rec.indexOf("age");
            int age_value = query.value(age_ptr).toInt();

            // 设置treeWidget属性
            ui->treeWidget->setColumnCount(3);         // 设置总列数
            ui->treeWidget->setColumnWidth(0,300);     // 设置最后一列宽度自适应
            ui->treeWidget->setIndentation(0);         // 设置表头缩进为0

            // 设置表头数据
            QStringList headers;
            headers.append("UID");
            headers.append("用户名");
            headers.append("年龄");

            ui->treeWidget->setHeaderLabels(headers);

            // 模拟插入数据到表中
            QTreeWidgetItem* item=new QTreeWidgetItem();
            item->setText(0,QString::number(id_value));
            item->setText(1,name_value);
            item->setText(2,QString::number(age_value));
            ui->treeWidget->addTopLevelItem(item);
        }
    }
}

// 根据ID查询数据
void MainWindow::on_pushButton_5_clicked()
{
    // 指定数据库驱动类型
    QSqlDatabase db = QSqlDatabase::addDatabase(ui->lineEdit_type->text());
    db.setDatabaseName(ui->lineEdit_dir->text());
    if (!db.open())
    {
        QMessageBox::information(nullptr, "信息", db.lastError().text(), QMessageBox::Ok);
    }

    // 查询数据
    QSqlQuery query("SELECT * FROM LyShark;",db);
    QSqlRecord rec = query.record();

    // 循环所有记录
    while(query.next())
    {
        // 判断当前记录是否有效
        if(query.isValid())
        {
            // 读出数据
            int id_ptr = rec.indexOf("id");
            int id_value = query.value(id_ptr).toInt();

            // 如果是则填充表格
            if(QString::number(id_value) == ui->lineEdit_select_uid->text())
            {
                int name_ptr = rec.indexOf("name");
                QString name_value = query.value(name_ptr).toString();
                ui->lineEdit_select_uname->setText(QString(name_value.data()));

                int age_ptr = rec.indexOf("age");
                QString age_value = query.value(age_ptr).toString();
                ui->lineEdit_select_uage->setText(QString(age_value.data()));
            }
        }
        else
        {
            ui->lineEdit_select_uname->setText("-1");
            ui->lineEdit_select_uage->setText("-1");
        }
    }
}

// 更新数据
void MainWindow::on_pushButton_6_clicked()
{
    // 指定数据库驱动类型
    QSqlDatabase db = QSqlDatabase::addDatabase(ui->lineEdit_type->text());
    db.setDatabaseName(ui->lineEdit_dir->text());
    if (!db.open())
    {
        QMessageBox::information(nullptr, "信息", db.lastError().text(), QMessageBox::Ok);
    }

    // 执行SQL更新记录
    int uid = ui->lineEdit_select_uid->text().toInt();
    QString name = ui->lineEdit_select_uname->text();
    int age = ui->lineEdit_select_uage->text().toInt();

    QString sql = QString("UPDATE LyShark SET name='%1', age=%2 WHERE id=%3;").arg(name).arg(age).arg(uid);
    db.exec(sql);
    std::cout << "update => " << sql.toStdString() << std::endl;

    // 提交事务请求
    bool ref = db.commit();
    if(ref == true)
    {
        QMessageBox::information(nullptr, "信息", "更新数据失败", QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(nullptr, "信息", "更新数据成功", QMessageBox::Ok);
    }

    db.close();
}
