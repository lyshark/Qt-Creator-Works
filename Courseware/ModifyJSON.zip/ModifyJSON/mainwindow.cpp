#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <iostream>

#include <QString>
#include <QTextStream>
#include <QMessageBox>

#include <QFile>
#include <QDir>
#include <QFileInfo>

#include <QJsonDocument>
#include <QJsonParseError>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonValueRef>

#include <QListView>
#include <QStandardItemModel>

// 定义全局字符串
QString config;

// 读取JSON文本
QString readonly_string(QString file_path)
{
    QFile this_file_ptr(file_path);
    if(false == this_file_ptr.exists())
    {
        return "None";
    }
    if(false == this_file_ptr.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        return "None";
    }
    QString string_value = this_file_ptr.readAll();
    this_file_ptr.close();
    return string_value;
}


// 写出JSON到文件
bool writeonly_string(QString file_path, QString file_data)
{
    QFile this_file_ptr(file_path);
    if(false == this_file_ptr.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        return false;
    }

    QByteArray write_byte = file_data.toUtf8();

    this_file_ptr.write(write_byte,write_byte.length());
    this_file_ptr.close();
    return true;
}

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 读取文件
    config = readonly_string("config.json");
    if(config == "None")
    {
        QMessageBox::information(nullptr,"提示","读取失败",QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(nullptr,"提示","JSON文件已被读入",QMessageBox::Ok);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}




























